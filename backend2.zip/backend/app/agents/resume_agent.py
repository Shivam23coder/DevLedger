"""
Resume agent: parses a PDF resume for (1) claimed skills via keyword
matching and (2) social/profile links - including links hidden behind
hyperlinked text like "GitHub", which plain text extraction misses.

Uses PyMuPDF (fitz) because it exposes link annotations (page.get_links()),
not just the visible text layer. pypdf/PyPDF2 alone cannot do this.
"""
import re

import fitz  # PyMuPDF

# Starter skill vocabulary - expand this list as the product grows.
# Kept flat and simple deliberately: a real v2 would use an embedding-based
# skill taxonomy, but keyword matching is transparent and easy to debug for v1.
SKILL_KEYWORDS = [
    "python", "java", "javascript", "typescript", "c++", "go", "rust",
    "react", "next.js", "node.js", "django", "flask", "fastapi", "spring boot",
    "postgresql", "mysql", "mongodb", "redis", "elasticsearch",
    "docker", "kubernetes", "aws", "gcp", "azure", "terraform",
    "ci/cd", "github actions", "jenkins",
    "machine learning", "tensorflow", "pytorch", "nlp",
    "graphql", "rest api", "microservices", "kafka", "rabbitmq",
    "competitive programming", "algorithms", "data structures",
]

LINK_PATTERNS = {
    "github": re.compile(r"github\.com/[\w\-]+", re.I),
    "linkedin": re.compile(r"linkedin\.com/in/[\w\-]+", re.I),
    "leetcode": re.compile(r"leetcode\.com/(?:u/)?[\w\-]+", re.I),
    "codeforces": re.compile(r"codeforces\.com/(?:profile|submissions)/[\w\-]+", re.I),
}


def extract_text_and_links(pdf_bytes: bytes) -> tuple[str, list[str]]:
    """Returns (full_text, list_of_hyperlink_uris) from annotation links,
    which is where 'GitHub' as clickable text actually stores its URL."""
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")

    full_text = ""
    hyperlinks: list[str] = []

    for page in doc:
        full_text += page.get_text()
        for link in page.get_links():
            uri = link.get("uri")
            if uri:
                hyperlinks.append(uri)

    return full_text, hyperlinks


def detect_profile_links(text: str, hyperlinks: list[str]) -> dict[str, str | None]:
    """Finds github/linkedin/leetcode links two ways:
    1. Embedded hyperlink annotations (e.g. "GitHub" text linked to a URL)
    2. Plain-text URLs typed directly (e.g. "github.com/username" as visible text)
    Hyperlink annotations take priority since they're less error-prone."""
    detected: dict[str, str | None] = {"github": None, "linkedin": None, "leetcode": None, "codeforces": None}

    search_spaces = hyperlinks + [text]

    for platform, pattern in LINK_PATTERNS.items():
        for space in search_spaces:
            match = pattern.search(space)
            if match:
                url = match.group(0)
                if not url.startswith("http"):
                    url = "https://" + url
                detected[platform] = url
                break

    return detected


def extract_claimed_skills(text: str) -> list[str]:
    """Word-boundary matching, not naive substring search - otherwise 'go'
    false-matches inside 'Google', 'background', etc.
    Uses lookaround instead of \\b because \\b breaks on skills like
    'c++' where the boundary character itself isn't a word character."""
    found = []
    for skill in SKILL_KEYWORDS:
        pattern = r'(?<![a-zA-Z0-9])' + re.escape(skill) + r'(?![a-zA-Z0-9])'
        if re.search(pattern, text, re.IGNORECASE):
            found.append(skill)
    return found


def parse_resume(pdf_bytes: bytes) -> dict:
    text, hyperlinks = extract_text_and_links(pdf_bytes)
    return {
        "claimed_skills": extract_claimed_skills(text),
        "detected_links": detect_profile_links(text, hyperlinks),
    }
